<?php

$username = "wackopicko";
$pass = "wackopicko";
$database = "wackopicko";

require_once("database.php");
$db = new DB("localhost", $username, $pass, $database);


?>