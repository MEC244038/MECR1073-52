<?php

// Setting to control what directory WackoPicko lives in.
const DIRECTORY = "/WackoPicko/";

?>